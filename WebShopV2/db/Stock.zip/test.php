<?php
	$thisy = date("Y");
	echo $thisy + 1;
	echo '<br>';
 	$thism date('m');
	echo '<br>';
 	$thisd date('d');
?>

<aside class="left-side sidebar-offcanvas">
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <!-- Sidebar user panel -->
                    <div class="user-panel">
                        <div class="pull-left image">
                            <img src="img/avatar3.png" class="img-circle" alt="User Image" />
                        </div>
                        <div class="pull-left info">
                            <p>Hello, <?php  echo $U_Acc; ?></p>

                            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
                        </div>
                    </div>
                    <!-- search form -->
                    <form action="#" method="get" class="sidebar-form">
                        <div class="input-group">
                            <input type="text" name="q" class="form-control" placeholder="Search..."/>
                            <span class="input-group-btn">
                                <button type='submit' name='search' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
                            </span>
                        </div>
                    </form>
                    <!-- /.search form -->
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    <ul class="sidebar-menu">
                       
                                             
						<?php
						if($_SESSION['Level']=='1'){
							echo '<li class="treeview">
								   <a href="">
										<i class="fa fa-dashboard"></i> <span>Buy Products</span>
										<i class="fa fa-angle-left pull-right"></i>
								   </a>
											<ul class="treeview-menu">
												<li><a href="index.php"><i class="fa fa-angle-double-right"></i> Buy Products </a></li>
												<li><a href="invoicebuying.php"><i class="fa fa-angle-double-right"></i> Buy History</a></li>
											</ul>
								</li>';
							echo'<li class="treeview">
								<a href="#"><i class="fa fa-gear fa-fw"></i> <span>Setting</span>
								<i class="fa fa-angle-left pull-right"></i>
								</a>
										<ul class="treeview-menu">
											<li><a href="frmbranch.php"><i class="fa fa-angle-double-right"></i> Branch</a></li>
											<li><a href="frmtotalproducts.php?BranchID=0"><i class="fa fa-angle-double-right"></i> All Products</a></li>
											<li><a href="frmCategory.php"><i class="fa fa-angle-double-right"></i> Category</a></li>
											
										</ul>
									
							
							</li>';
						}
						
						
						?>
						<li class="treeview">
                           <a href="">
                                <i class="fa fa-dashboard"></i> <span>Sale Products</span>
                                <i class="fa fa-angle-left pull-right"></i>
                           </a>
                                    <ul class="treeview-menu">
                                        <li><a href="frmSalePrd.php"><i class="fa fa-angle-double-right"></i> Sale Products </a></li>
                                        <li><a href="invoicesaling.php"><i class="fa fa-angle-double-right"></i> Sale History</a></li>
                                        <?php
											if($_SESSION['Level']=='2'){
												echo '<li><a href="frmtotalproducts_user.php"><i class="fa fa-angle-double-right"></i> All Products</a></li>';
											}
										?>
                                    </ul>
                        </li>
						<li class="treeview">
                            <a href="userAccount.php">
                                <i class="fa fa-user fa-fw"></i> <span>User Account</span>
								<i class="fa fa-angle-left pull-right"></i>
                            </a>
									<ul class="treeview-menu">
										<?php
											if($_SESSION['Level']=='1'){
												echo ' <li><a href="userAccount.php"><i class="fa fa-angle-double-right"></i> User </a></li>';
											}
										?>
                                       
										
                                        <li><a href="UserChangePassword.php"><i class="fa fa-angle-double-right"></i> Change Password</a></li>
										<li><a href="logout.php"><i class="fa fa-angle-double-right"></i> Logout</a></li>
									</ul>
						</li>
                        
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>